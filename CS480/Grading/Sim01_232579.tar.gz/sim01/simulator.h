#ifndef SIMULATOR_H
#define SIMULATOR_H

#include "configops.h"
#include "metadataops.h"

// function declaration
void runSim( ConfigDataType *configPtr, OpCodeType *metaDataMstrPtr );


#endif // SIMULATOR_H